package fdffd.com.tutorials.hp.restaurantapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    public static int index;
   DatabaseReference database;

   ArrayList<String> description  = new ArrayList<String>(){{add("this is a wonderful restaurant");}};






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView)findViewById(R.id.lvRestaurants);
        final ArrayList<String> values1 = new ArrayList<String>(){{add("IHOP");
            add("Subway"); add("starbucks"); add("teastation");}};


        database = FirebaseDatabase.getInstance().getReference("restaurants");










        CustomAdapter adapter;
        adapter = new CustomAdapter(this, values1);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                index = position;

                String id1 = database.push().getKey();









                if(position == 0) {
                    Restaurant restaurant = new Restaurant(values1.get(0), Menus.menusForIhop.get(0), Menus.menusForIhop.get(1), Menus.menusForIhop.get(2));
                    database.child(id1).setValue(restaurant);

                }
                 if(position == 1) {
                     Restaurant restaurant1 = new Restaurant(values1.get(1), Menus.menusForSubway.get(0), Menus.menusForSubway.get(1), Menus.menusForSubway.get(2));
                     database.child(id1).setValue(restaurant1);
                 }
                 if(position == 2) {
                     Restaurant restaurant2 = new Restaurant(values1.get(2), Menus.menusForStarbucks.get(0), Menus.menusForStarbucks.get(1), Menus.menusForStarbucks.get(2));
                     database.child(id1).setValue(restaurant2);
                 }
                 if(position == 3) {
                     Restaurant restaurant3 = new Restaurant(values1.get(3), Menus.menusForTeastation.get(0), Menus.menusForTeastation.get(1), Menus.menusForTeastation.get(2));
                     database.child(id1).setValue(restaurant3);
                 }








                Intent intent = new Intent(MainActivity.this,Menus.class);
                startActivity(intent);

            }
        });


    }

}
