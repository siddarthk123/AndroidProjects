package fdffd.com.tutorials.hp.restaurantapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Menus extends AppCompatActivity  {


    ListView listView1;
    public static ArrayList<String> menusForIhop = new ArrayList<String>(){{add("omelete $5.00");
    add("pancake $3.00"); add("orange juice $1.50");}};


    public static ArrayList<String> menusForSubway = new ArrayList<String>(){{add("Veggie Delight $5.00");
        add("Meatsub $3.00"); add("drink of any choice $1.50");}};

    public static ArrayList<String> menusForStarbucks = new ArrayList<String>(){{add("cappachino $5.25");
        add("late $3.00"); add("crossaint $1.75");}};

    public static ArrayList<String> menusForTeastation = new ArrayList<String>(){{add("Slushi with boba $3.75");
        add("iced tea $3.00"); add("Milk ice tea $1.25");}};






    EditText et;

    TextView tv;




    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menus);


        listView1= (ListView)findViewById(R.id.lvMenuz);




















            if(MainActivity.index == 0) {
                CustomAdapter adapter = new CustomAdapter(this, menusForIhop);


                listView1.setAdapter(adapter);
            }


        if(MainActivity.index == 1) {
            CustomAdapter adapter = new CustomAdapter(this,menusForSubway);


            listView1.setAdapter(adapter);
        }


        if(MainActivity.index == 2) {
            CustomAdapter adapter = new CustomAdapter(this,menusForStarbucks);


            listView1.setAdapter(adapter);
        }


        if(MainActivity.index == 3) {
            CustomAdapter adapter = new CustomAdapter(this,menusForTeastation);


            listView1.setAdapter(adapter);
        }








    }
}
