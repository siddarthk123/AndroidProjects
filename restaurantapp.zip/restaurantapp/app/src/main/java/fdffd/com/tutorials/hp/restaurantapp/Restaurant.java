package fdffd.com.tutorials.hp.restaurantapp;

/**
 * Created by family on 11/19/17.
 */

public class Restaurant {

    public  String name;

    public String menuItem1;
    public String menuItem2;
    public String menuItem3;

    public Restaurant(String name,String menuItem1,String menuItem2, String menuItem3){



        this.menuItem1 = menuItem1;
        this.menuItem2 = menuItem2;
        this.menuItem3 = menuItem3;
         this.name = name;


    }
}
