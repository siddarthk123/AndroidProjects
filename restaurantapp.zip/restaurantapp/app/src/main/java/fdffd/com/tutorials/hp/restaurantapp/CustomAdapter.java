package fdffd.com.tutorials.hp.restaurantapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;


import java.sql.Array;
import java.util.ArrayList;

/**
 * Created by family on 11/18/17.
 */

public class CustomAdapter extends ArrayAdapter<String> {


    public static int index;

    private final Context context;
    public ArrayList<String> values = new ArrayList<String>(){{add("IHOP");
        add("Subway"); add("starbucks"); add("teastation");}};






    public CustomAdapter(@NonNull Context context, ArrayList<String> values) {
        super(context,R.layout.restaurant,values);

        this.context = context;
        this.values = values;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView =  inflater.inflate(R.layout.restaurant,parent, false);


        index = position;

        TextView etText = (TextView)rowView.findViewById(R.id.etText);





        etText.setText(values.get(position));

        return rowView;
    }
}
