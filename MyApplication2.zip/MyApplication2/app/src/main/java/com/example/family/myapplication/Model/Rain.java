package com.example.family.myapplication.Model;

/**
 * Created by family on 11/8/17.
 */

public class Rain {
}
