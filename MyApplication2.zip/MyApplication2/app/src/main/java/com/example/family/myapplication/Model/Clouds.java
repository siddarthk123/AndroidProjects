package com.example.family.myapplication.Model;

/**
 * Created by family on 11/8/17.
 */

public class Clouds {

    private int all;

    public Clouds(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
