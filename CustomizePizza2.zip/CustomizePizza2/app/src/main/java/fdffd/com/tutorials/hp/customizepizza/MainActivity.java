package fdffd.com.tutorials.hp.customizepizza;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;




public class MainActivity extends AppCompatActivity {


    boolean peppCheck1 = false;
    int count1 = 0;
    int count2 = 0;
    int count3= 0;
    double total = 5.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final CheckBox checkBox = (CheckBox)findViewById(R.id.peppCheck);
        final CheckBox checkBox1 = (CheckBox)findViewById(R.id.vegCheck);
        final CheckBox checkBox2 = (CheckBox)findViewById(R.id.pineappleCheck);
        final TextView showText = (TextView)findViewById(R.id.showText);
        final Button orderAgain = (Button)findViewById(R.id.orderAgain);




        Button orderButton = (Button)findViewById(R.id.orderButton);


        boolean pinappleCheck = false;
        boolean vegCheck = false;
        boolean peppCheck = false;



        final StringBuilder sb = new StringBuilder();
        sb.append("Your order is pizza $5.00 with: ");

        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox.isChecked() && count1 < 1){
                   sb.append("\n pepporoni $0.50 ");
                   total += .50;
                   count1++;
                }
            }

        });

        checkBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(checkBox1.isChecked() && count2 < 1){
                    sb.append("\n vegetables $0.50 ");
                    total +=.50;
                    count2++;
                }

            }
        });

        checkBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(checkBox1.isChecked() && count3 < 1){
                    sb.append("\n pineapples $0.70 ");
                    total +=.70;
                    count3++;
                }

            }
        });

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showText.setText(sb.toString() + "\n" + "and your total is " + total);


            }
        });


        orderAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                total = 5.00;
                count1 = 0;
                count2 = 0;
                count3 = 0;
                showText.setText("");
                sb.delete(0,sb.length());
            }
        });


    }
}
